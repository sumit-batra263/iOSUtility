
	//  Utility.m
	//  Created by Sumit Batra on 03/06/19.

#import "Utility.h"

@implementation Utility

#pragma -
#pragma mark - Helper methods

/*
    Detects whether the device is iPhone or iPad
 */
+(BOOL)isIpad
{
    BOOL isIpad;
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
        isIpad = YES;
    else
        isIpad = NO;
    
    return isIpad;
}

/*
    Detects the device's Portrait orientation
 */
+(BOOL)isPortrait
{
    BOOL value;
    if ([[UIDevice currentDevice] orientation] == UIInterfaceOrientationPortrait)
        value = TRUE;
    else
        value = FALSE;
    
    return value;
}

/*
    Returns device OS Version
 */
+(CGFloat)deviceOSVersion
{
    CGFloat version;
    version = [[[UIDevice currentDevice] systemVersion] floatValue];
    return version;
}


#pragma -
#pragma mark - Date Methods

/* Use this method to convert an NSDate object into NSString.
   @param date, a NSDate object.
   @param dateFormat, a NSString object specifying the format to be used to convert a NSDate object into NSString.
   @return NSString, representing the date.
 */

+(NSString *)getDateAsString:(NSDate *) date usingFormat:(NSString *) dateFormat{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:dateFormat];
    NSString *dateAsString = [dateFormatter stringFromDate:date];
    return dateAsString;
}

/* Use this method to convert a NSString object into NSDate.
   @param dateString, a NSString object having string in date format.
   @param dateFormat, a NSString object specifying the format to be used to convert a NSDate object into NSString.
   @param NSDate, a NSDate object.
 */
+(NSDate *)getStringAsDate:(NSString *) dateString usingFormat:(NSString *) dateFormat{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:dateFormat];
    NSDate *date = [dateFormatter dateFromString:dateString];
    return date;
}

#pragma -
#pragma mark - Json To Dictionary, Vice Versa Methods
/* Use this method to convert a JSON string into a NSDictionary object.
 @param json, a NSString object having json content.
 @param NSDictionary, containing key-value pair from JSON String.
 */
+(NSDictionary *) convertJSONToDictionary:(NSString *)json{
    NSDictionary * dict = nil;
    if (json.length > 0){
        NSError *error = nil;
        NSData *data = [json dataUsingEncoding:NSUTF8StringEncoding];
        dict  = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
    }
    return dict;
}

/*
   Use this method to convert a string point (x,y) into a CGPoint object.
 */
+(CGPoint)convertStringPointToCGPoint:(NSString *)pointString{
    CGPoint point = CGPointZero;
    NSArray *cxy =  [pointString componentsSeparatedByString:@","];
    if (cxy.count > 1){
        CGFloat x = [[cxy objectAtIndex: 0] floatValue];
        CGFloat y = [[cxy objectAtIndex: 1] floatValue];
        CGPoint xy = CGPointMake(x, y);
        point = xy;
    }
    return point;
}


#pragma -
#pragma mark - Image Handling Methods (Embedded Custom Frameworks)
/*
 Use this method to get an image from a framework bundle.
 */
+(UIImage *)getImageForName:(NSString *)imageName{
    NSString *newImagePath = [[Utility getCurrentBundle] pathForResource:imageName ofType: @"png"];
    UIImage *newImage = [[UIImage imageNamed:newImagePath] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    return newImage;
}

/*
 Use this method to get an image from a url resource.
 */
+ (UIImage *) getImageFromUrl:(NSString *)urlString {
    NSURL *imageUrl = [NSURL URLWithString: urlString];
    NSData *imageData = [NSData dataWithContentsOfURL: imageUrl];
    UIImage *downloadedImage = [[UIImage alloc] initWithData: imageData];
    return downloadedImage;
}

#pragma -
#pragma mark - Access iPhone Directories
/*
 Use this method to get the budle using bundle ID.
 */
+ (NSBundle *) getCurrentBundle {
    NSString* const frameworkBundleID =@"PLEASE ENTER BUNDLE ID";
    NSBundle* currentbundle = [NSBundle bundleWithIdentifier:frameworkBundleID];
    return currentbundle;
}
/*
 Use this method to know if a file exits at given path.
 */
+(BOOL)isFileExist:(NSString*)path{
    return  [[NSFileManager defaultManager] fileExistsAtPath:path];
}

/*
 Use this method to get the iPhone document directory path.
 */
+ (NSString *) getDocumentDirectoryPath {
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	return documentsDirectory;
}

/*
 Use this method to get the iPhone cache directory path.
 */
+ (NSString *) getCacheDirectoryPath {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *cacheDirectory = [paths objectAtIndex:0];
    return cacheDirectory;
}

/*
 Use this method to know if a file exits at path.
 */
+(BOOL) isDirectoryExist:(NSString*) path{
    BOOL is = NO;
    if([[NSFileManager defaultManager] fileExistsAtPath:path isDirectory:&is])
        return YES;
    return NO;
}

/*
    This is a method which searches for a file in NSLibraryDirectory
    and returns the absolute path for the file
 */
+ (NSString*)fullLibraryPathForResource:(NSString*)resourceName
{
    NSAssert(resourceName != nil, @"Global: Invalid resourceName");
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask,YES);
    NSMutableString *documentsDirectory = [[NSMutableString alloc]initWithString:[paths objectAtIndex:0]];
    documentsDirectory = (NSMutableString*)[documentsDirectory stringByAppendingString:[NSString stringWithFormat:@"/%@",resourceName]];
    if(![fileManager fileExistsAtPath:documentsDirectory])
        return nil;
    return documentsDirectory;
}

/*
 Use this method to know if a file exits for a given file name. Here we are passing the name of file not the actual file path.
 */
+ (BOOL)checkIfFileExistsAtPath:(NSString *)fileName
{
    BOOL fileFound = NO;
    NSString *filePath  = [[NSBundle mainBundle] pathForResource:[fileName stringByDeletingPathExtension] ofType:[fileName pathExtension]];
    if(![[NSFileManager defaultManager] fileExistsAtPath:filePath]){
        fileFound = YES;
    }
    else{
        fileFound = YES;
    }
    return fileFound;
}

/*
 Use this method to move a resource from a bundle to the iPhone cache.
 */
+(BOOL)moveResourceToCache:(NSString *)resourceName extenstion:(NSString *) extension
{
    BOOL isFileMoved = false;
    NSError *error;
    NSString *srcName = [NSString stringWithFormat:@"%@.%@", resourceName, extension];
    
    NSString *path = [[Utility getCacheDirectoryPath] stringByAppendingPathComponent:srcName];
    
    if(![[NSFileManager defaultManager] fileExistsAtPath:path])
    {
        NSString *bundlePath = [[NSBundle mainBundle] bundlePath];
        NSString *srcBundlePath = [bundlePath stringByAppendingPathComponent:srcName];
        isFileMoved = [[NSFileManager defaultManager] copyItemAtPath:srcBundlePath toPath:path error:&error];
    }
    return isFileMoved;
}

/*
 Use this method to remove a resource from a bundle to the iPhone cache.
 */
+(BOOL)removeResourceFromCache:(NSString *)resourceName extenstion:(NSString *) extension
{
    NSError *error;
    BOOL isFileRemoved = false;
    NSString *srcName = [NSString stringWithFormat:@"%@.%@", resourceName, extension];
    NSString *path = [[Utility getCacheDirectoryPath] stringByAppendingPathComponent:srcName];
    
    if([[NSFileManager defaultManager] fileExistsAtPath:path])
    {
      isFileRemoved = [[NSFileManager defaultManager] removeItemAtPath:path error:&error];
    }
    return isFileRemoved;
}


#pragma -
#pragma mark - UIColor custom method
/*
 Use this method to get a UIColor object from a hexString.
 */
+ (UIColor *) getColorFromHexString:(NSString *)hexString {
	unsigned rgbValue = 0;
	NSScanner *scanner = [NSScanner scannerWithString:hexString];
	[scanner setScanLocation:1]; // bypass '#' character
	[scanner scanHexInt:&rgbValue];
	return [UIColor colorWithRed:((rgbValue & 0xFF0000) >> 16)/255.0 green:((rgbValue & 0xFF00) >> 8)/255.0 blue:(rgbValue & 0xFF)/255.0 alpha:1.0];
}

#pragma -
#pragma mark - Layer methods
// Function to bring the sub layer to front
+ (void)bringSublayerToFront:(CALayer *)layer {
	CALayer *superlayer = layer.superlayer;
	[layer removeFromSuperlayer];
	int index = (int)[superlayer.sublayers count];
	[superlayer insertSublayer:layer atIndex: index];
}

// Function to bring the sub layer to back
+ (void)sendSublayerToBack:(CALayer *)layer {
	CALayer *superlayer = layer.superlayer;
	[layer removeFromSuperlayer];
	[superlayer insertSublayer:layer atIndex:0];
}

#pragma -
#pragma mark - Sorting methods
/*
    Use this method to sort a dictionary.
 */
+ (NSArray *) sortDictionaryData: (NSDictionary *)dataDictionary {
	NSArray *keys = [dataDictionary allKeys];
	keys = [keys sortedArrayUsingComparator:^(id a, id b) {
		return [a compare:b options:NSNumericSearch];
	}];
	return keys;
}
@end
