
//  Constants.h
//  Created by Sumit Batra

#ifndef Constants_h
#define Constants_h

//For debugging
#define IS_DEBUG_MODE 0

//For enabling log printing
#define NSLog if(1)NSLog

//RBG Color Code Macro
#define RGB(r,g,b) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1.0]

//Macros for Detecting Device
#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
//For iPhone 4, 4s
#define IS_IPHONE_4_EQUIVALENT (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 480.0)
//For iPhone 5, 5s, SE
#define IS_IPHONE_5_EQUIVALENT (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 568.0)
//For iPhone 6, 7, 8
#define IS_IPHONE_6_EQUIVALENT (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 667.0)
//For iPhone 6PLUS, 7PLUS, 8PLUS
#define IS_IPHONE_6_PLUS_EQUIVALENT (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 736.0)
//For iPhoneX
#define IS_IPHONE_X (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 812.0)
//For iPhoneX & ABOVE like XR, XSMAX
#define IS_IPHONE_X_ABOVE (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height >= 812.0)
//For iPhoneXR
#define IS_IPHONE_XR (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 896.0)
//For iPhoneXSMAX
#define IS_IPHONE_XS_MAX (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 896.0)

// Useful wheb you are using this file as part of framework then define the framework bundle id here.
#define kFrameworkBundleID  @"";

//Macros pointing to APIs path
#define kApiBaseUrl         @""

//Scaling Macros
#define MAX_SCALE 1.0
#define MIN_SCALE 1.0

//Numeric constants as macros
#define ZERO    0
#define ONE     1
#define TWO     2
#define THREE   3
#define FOUR    4
#define FIVE    5
#define SIX     6
#define SEVEN   7
#define EIGHT   8
#define NINE    9
#define TEN     5

//Floating point constants as macros
#define ZERO_F  0.0
#define ONE_F   1.0
#define TWO_F   2.0
#define THREE_F 3.0
#define FOUR_F  4.0
#define FIVE_F  5.0
#define SIX_F   6.0
#define SEVEN_F 7.0
#define EIGHT_F 8.0
#define NINE_F  9.0
#define TEN_F   10.0
#define POINT_NINE 0.9

//Time based macros
#define ZERO_SEC  0.0f
#define ONE_SEC   1.0f
#define ONE_MILLI_SEC   1.0/1000.0f

// IMAGE Extension Constants
#define PNG @"png"
#define JPEG @"jpeg"
#define GIF @"gif"
#define SVG @"svg"

//Sound File Extension Constants
#define MP3 @"mp3"
#define MP4 @"mp4"
#define WAV @"wav"
#define MOV @"mov"

#define NOTIFICATIONS_ON_OFF    @"NOTIFICATIONS_ON_OFF"

//App Related Macro
#define AppVersion @"AppVersion"
#define AppReleaseDate @"ReleaseDate"

#endif /* Constants_h */
