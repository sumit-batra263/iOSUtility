
//  Utility.h
//  Created by Sumit Batra on 03/05/19 (MM/DD/YYYY).

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@interface Utility : NSObject

//Helper methods
+(BOOL)isIpad;
+(BOOL)isPortrait;
+(CGFloat)deviceOSVersion;

//iPhone Directory related methods
+(NSBundle *)getCurrentBundle;
+(BOOL)isFileExist:(NSString*)path;
+(NSString *)getDocumentDirectoryPath;
+(NSString *)getCacheDirectoryPath;
+(BOOL)isDirectoryExist:(NSString*) path;
+(BOOL)checkIfFileExistsAtPath:(NSString *)fileName;
+(NSString*)fullLibraryPathForResource:(NSString*)resourceName;
+(BOOL)moveResourceToCache:(NSString *)resourceName extenstion:(NSString *) extension;
+(BOOL)removeResourceFromCache:(NSString *)resourceName extenstion:(NSString *) extension;

//Handling date
+(NSString *)getDateAsString:(NSDate *) date usingFormat:(NSString *) dateFormat;
+(NSDate *)getStringAsDate:(NSString *) dateString usingFormat:(NSString *) dateFormat;

//Handling JSON
+(NSDictionary *)convertJSONToDictionary:(NSString *)json;
+(CGPoint)convertStringPointToCGPoint:(NSString *)pointString;

//Handling Images
+(UIImage *)getImageForName:(NSString *)imageName;
+(UIImage *)getImageFromUrl:(NSString *)urlString;

//get UIColor using hex
+(UIColor *)getColorFromHexString:(NSString *)hexString;

+(void)bringSublayerToFront:(CALayer *)layer;
+(void)sendSublayerToBack:(CALayer *)layer;

//Sorting method
+(NSArray *)sortDictionaryData: (NSDictionary *)dataDictionary;

@end
